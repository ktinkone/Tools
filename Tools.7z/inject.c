#include "inject.h"

#include<stdio.h>
#include<fcntl.h>
#include<string.h>


/**********************************************************************************
*init target file
**********************************************************************************/
int init_target_file(Global_Var *global_var) {
	unsigned int index;
	unsigned int len;
	unsigned int count;
	char buf[1024];
	memset(buf,0,1024);
	len = global_var->sht_offset + global_var->sect_num * global_var->elf_hdr.e_shentsize;
	printf("target file len :%8x\n",len);
	//constrcut target file
	len = 1124;
	for (index=0; index < len; index++) {
		count = (len - index) > 1024 ? 1024 : len - index;
		fwrite(buf,count,1,global_var->tgt_fp);
		index += count;
	}
}

/**********************************************************************************
*write elf header 
**********************************************************************************/
int write_elf_header(Global_Var *global_var) {
	
}