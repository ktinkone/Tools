#ifndef _INJECT_H
#define _INJECT_H

#include<stdio.h>
#include"global.h"

int init_target_file(Global_Var* global_var);
int write_elf_header(Global_Var* global_var);

#endif